package com.ibm.testcases;

import org.testng.annotations.Test;

import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
@CucumberOptions(
		features = "src/test/resources/feature/",
		glue = {"com.ibm.steps"}
		)

public class TestExecutor extends AbstractTestNGCucumberTests{
  @Test
  public void f() {
  }
}
