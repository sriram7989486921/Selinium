package com.ibm.excelreader;

import java.util.List;
import java.util.Map;

public class TestExecutor {
    public static void main(String[] args) {
        String filePath = "src/test/resources/testdata/RegistrationLoginData.xlsx";
        String sheetName = "Sheet1";

        // Get Login Data
        List<Map<String, String>> loginData = ExcelDrivenReader.getTestData(filePath, sheetName, "Login");
        for (Map<String, String> data : loginData) {
            System.out.println("🔐 Login => Username: " + data.get("Email") + ", Password: " + data.get("Password"));
        }

        // Get Registration Data
        List<Map<String, String>> registerData = ExcelDrivenReader.getTestData(filePath, sheetName, "Register");
        for (Map<String, String> data : registerData) {
            System.out.println("📝 Register => FullName: " + data.get("FullName") + ", Email: " + data.get("Email"));
        }
    }
}
