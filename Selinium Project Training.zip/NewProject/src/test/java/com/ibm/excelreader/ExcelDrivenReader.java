package com.ibm.excelreader;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDrivenReader {

    public static List<Map<String, String>> getTestData(String filePath, String sheetName, String keywordFilter) {
        List<Map<String, String>> testDataList = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(new File(filePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                System.err.println("❌ Sheet '" + sheetName + "' not found.");
                return testDataList;
            }

            Row headerRow = sheet.getRow(0); // First row = header
            int lastRow = sheet.getLastRowNum();

            for (int i = 1; i <= lastRow; i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                Cell keywordCell = row.getCell(10); // Column 10 is 'Keyword'
                if (keywordCell == null || !keywordCell.getStringCellValue().equalsIgnoreCase(keywordFilter)) continue;

                Map<String, String> rowData = new HashMap<>();
                for (int j = 0; j < headerRow.getLastCellNum(); j++) {
                    String header = headerRow.getCell(j).getStringCellValue();
                    String value = "";
                    Cell cell = row.getCell(j);
                    if (cell != null) {
                        switch (cell.getCellType()) {
                            case STRING:
                                value = cell.getStringCellValue();
                                break;
                            case NUMERIC:
                                value = String.valueOf((long) cell.getNumericCellValue()); // For phone/zipcode
                                break;
                            default:
                                value = "";
                        }
                    }
                    rowData.put(header.trim(), value.trim());
                }

                testDataList.add(rowData);
            }

        } catch (Exception e) {
            System.err.println("❌ Error reading Excel: " + e.getMessage());
            e.printStackTrace();
        }

        return testDataList;
    }
}
