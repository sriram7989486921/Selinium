package com.ibm.pages;

import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.ibm.steps.ConfigReader;

public class DriveManger {
    private static WebDriver driver;

    public static WebDriver setup() {
        if (driver == null) {
            String browser = ConfigReader.getProperty("browser");
            String gridUrl = ConfigReader.getProperty("grid.url");

            try {
                if (gridUrl != null && !gridUrl.isEmpty()) {
                    ChromeOptions options = new ChromeOptions();
                    driver = new RemoteWebDriver(new URL(gridUrl), options);
                } else {
                    driver = new ChromeDriver();
                }
                driver.manage().window().maximize();
            } catch (Exception e) {
                throw new RuntimeException("Driver init failed", e);
            }
        }
        return driver;
    }

    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }
}
