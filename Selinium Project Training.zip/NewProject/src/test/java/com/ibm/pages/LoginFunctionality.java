package com.ibm.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginFunctionality {
	WebDriver driver;
	WebDriverWait wait;
	
	//constructor only using construtor we can take driver or webdriverwait or webelements
	public LoginFunctionality(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	}
	
	

	//locators
	By signupname = By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[2]");
	By signupemail = By.xpath("//*[@id=\"form\"]/div/div/div[3]/div/form/input[3]");
	By signuppassword = By.xpath("//*[@id=\"password\"]");
	By signinpassword = By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[3]");
	By firstname = By.xpath("//*[@id=\"first_name\"]");
	By lastname = By.xpath("//*[@id=\"last_name\"]");
	By adress = By.xpath("//*[@id=\"address1\"]");
	By state = By.xpath("//*[@id=\"state\"]");
	By city = By.xpath("//*[@id=\"city\"]");
	By Zipcode = By.xpath("//*[@id=\"zipcode\"]");
	By mobilenumber =By.xpath("//*[@id=\"mobile_number\"]");
	By signinTest  = By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a");
	By signinemail = By.xpath("//*[@id=\"form\"]/div/div/div[1]/div/form/input[2]");
	By submitButton = By.xpath("//*[@id=\"form\"]/div/div/div/div[1]/form/button");
	
	public void signupName(String name) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signupname)).sendKeys(name);
	}
	
	public void signupEmail(String Email) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signupemail)).sendKeys(Email);
	}
	
	public void signupsubmit() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signupemail)).submit();
	}
	
	public void signinsubmit() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signinpassword)).submit();
	}
	
	public void siginclick() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signinTest)).click();
	}
	
	public void password(String pass) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signuppassword)).sendKeys(pass);
	}
	
	public void siginpass(String password) {
	    WebElement passField = wait.until(ExpectedConditions.visibilityOfElementLocated(signinpassword));
	    passField.clear();                      // Clear existing text
	    passField.sendKeys(password);          // Enter new password
	}

	public void firstname(String fname) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(firstname)).sendKeys(fname);
	}
	
	public void lastname(String lname) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(lastname)).sendKeys(lname);
	}
	
	public void adress(String adr) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(adress)).sendKeys(adr);
	}
	
	public void state(String stat) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(state)).sendKeys(stat);
	}
	
	public void city(String cty) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(city)).sendKeys(cty);
	}
	
	public void Zipcode(String zipcodes) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Zipcode)).sendKeys(zipcodes);
	}
	
	public void mobilenumber(String phonenum) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(mobilenumber)).sendKeys(phonenum);
	}
	
	public void signinemail(String signinmail) {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(signinemail));
		element.clear();
		element.sendKeys(signinmail);
	}

}
