package com.ibm.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PaymentsFunctionaly {
	WebDriver driver;
	WebDriverWait wait;
	
	public PaymentsFunctionaly(WebDriver driver) {
		this.driver=driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	
	//locators
	By Proceed = By.xpath("//*[@id=\"do_action\"]/div[1]/div/div/a");
	By checkout = By.xpath("//*[@id=\"cart_items\"]/div/div[7]/a");
	By fullname = By.xpath("//*[@id=\"payment-form\"]/div[1]/div/input");
	By cardnumber =By.xpath("//*[@id=\"payment-form\"]/div[2]/div/input");
	By cvv = By.xpath("//*[@id=\"payment-form\"]/div[3]/div[1]/input");
	By month = By.xpath("//*[@id=\"payment-form\"]/div[3]/div[2]/input");
	By year = By.xpath("//*[@id=\"payment-form\"]/div[3]/div[3]/input");
	By paymentSubmit = By.xpath("");
	
	public void Proceed() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(Proceed));
		element.click();
	}
	
	public void checkout() {
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(checkout));
		element.click();
	}
	
	public void name(String name) {
		driver.findElement(fullname).sendKeys(name);;
	}
	
	public void cardnumber(String crdnum) {
		driver.findElement(cardnumber).sendKeys(crdnum);
	}
	
	public void cvv(String Cv) {
		driver.findElement(cvv).sendKeys(Cv);;
	}
	
	public void month(String Month) {
		driver.findElement(month).sendKeys(Month);
	}
	
	public void year(String Yr) {
		driver.findElement(year).sendKeys(Yr);
	}
	
	public void paymentSubmit() {
		driver.findElement(year).submit();
	}
}
