package com.ibm.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomeFunctionality {
	WebDriver driver;
	WebDriverWait wait;
	
	public HomeFunctionality(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	}
	
	By Womenselection = By.xpath("//*[@id=\"accordian\"]/div[1]/div[1]/h4/a");
	By KidsSelection =By.xpath("//*[@id=\"accordian\"]/div[3]/div[1]/h4/a");
	By KidsTypeSelection = By.xpath("//*[@id=\"Kids\"]/div/ul/li[1]/a");
	By ProductObserving =By.xpath("/html/body/section/div/div[2]/div[2]/div/div[7]/div/div[2]/ul/li/a");
	
	public void Womenselection() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Womenselection)).click();
	}
	public void KidsSelection() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(KidsSelection)).click();
	}
	public void KidsTypeSelection() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(KidsTypeSelection)).click();
	}
	public void ProductObserving() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(ProductObserving)).click();
	}
}
