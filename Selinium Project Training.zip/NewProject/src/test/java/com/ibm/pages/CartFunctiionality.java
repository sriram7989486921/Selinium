package com.ibm.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartFunctiionality {
	WebDriver driver;
	WebDriverWait wait;
	public CartFunctiionality(WebDriver driver) {
		this.driver = driver;
		 this.wait = new WebDriverWait(driver, Duration.ofSeconds(6));
	}
	
	//locators
	By quantity = By.id("quantity");
	By AddToCart = By.xpath("/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button");
	By ClickingCart = By.xpath("//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a");
	
	public void quantity() {
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(quantity));
		element.clear();
		element.click();
		element.sendKeys("3");
	}
	
	public void AddToCart() {
		wait.until(ExpectedConditions.elementToBeClickable(AddToCart)).click();
	}
	
	public void ClickingCart() {
		wait.until(ExpectedConditions.elementToBeClickable(ClickingCart)).click();
	}
}
