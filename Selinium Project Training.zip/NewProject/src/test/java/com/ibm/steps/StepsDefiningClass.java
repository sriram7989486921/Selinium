package com.ibm.steps;

import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ibm.excelreader.ExcelDrivenReader;
import com.ibm.pages.CartFunctiionality;
import com.ibm.pages.DriveManger;
import com.ibm.pages.HomeFunctionality;
import com.ibm.pages.LoginFunctionality;
import com.ibm.pages.PaymentsFunctionaly;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepsDefiningClass {
	static WebDriver  driver;
	static WebElement element;
	static WebDriverWait driverWait;
	LoginFunctionality loginpage;
	HomeFunctionality Homepage;
	CartFunctiionality cartpage;
	PaymentsFunctionaly payments;
	List<Map<String, String>> regData;
	List<Map<String, String>> loginData;
	DriverManager manager;
	
	@Before
	public void setup() {
		driver = DriveManger.setup();
		driver.manage().window().maximize();
		
	}
	@Given("user is on home page")
	public void user_is_on_home_page() throws InterruptedException {
		String url = ConfigReader.getProperty("url");
	   driver.get(url);
	   System.out.println("ok this is working");
	   element = driver.findElement(By.xpath("//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[4]/a"));
	   element.click();
	}
	@When("user taking data from excel sheet {string}")
	public void user_taking_data_from_excel_sheet(String keyword) {
        String excelPath = "src/test/resources/testcases/LoginData(ddt).xlsx";
        regData = ExcelDrivenReader.getTestData(excelPath, "Sheet1", "register");
        loginData = ExcelDrivenReader.getTestData(excelPath, "Sheet1", "login");
        System.out.println("✅ Loaded data rows: " + regData.size());
    }
	@When("user login with creditinals")
	public void user_login_with_creditinals() throws InterruptedException {
		for (Map<String, String> data : regData) {
		loginpage = new LoginFunctionality(driver);
		loginpage.signupName(data.get("FullName"));
		loginpage.signupEmail(data.get("Email"));
		loginpage.signupsubmit();
//		Thread.sleep(3000);
		
		System.out.println("this is regdata"+data.get("Password"));
		break;
		}
	}
	
	@When("user  Registered with Credintials")
	public void user_registered_with_credintials() throws InterruptedException {
		for (Map<String, String> data : regData) {
		loginpage = new LoginFunctionality(driver);
		loginpage.password(data.get("Password"));
		loginpage.firstname(data.get("FirstName"));
		loginpage.lastname(data.get("LastName"));
		loginpage.adress(data.get("Address"));
		loginpage.state(data.get("State"));
		loginpage.city(data.get("City"));
		loginpage.Zipcode(data.get("Zipcode"));
		loginpage.mobilenumber(data.get("Mobile Number"));
		loginpage.siginclick();//@todo : i need to remove this and click on enter for succesfull registration up to that no succesfull registration login with fake details
		break;
		}
		for (Map<String, String> data : loginData) {
			driverWait = new WebDriverWait(driver, Duration.ofSeconds(3));
			loginpage.signinemail(data.get("Email"));
			loginpage.siginpass(data.get("Password"));
			loginpage.signinsubmit();
			driver.navigate().refresh(); // Refresh the current page

		}
	}

	@When("user search and  adding products to cart")
	public void user_search_and_adding_products_to_cart() throws InterruptedException {
		Homepage = new HomeFunctionality(driver);
		Homepage.Womenselection();
		Thread.sleep(1000);
		Homepage.KidsSelection();
		Thread.sleep(1000);
		Homepage.KidsTypeSelection();
		Thread.sleep(1000);
		Homepage.ProductObserving();
		Thread.sleep(2000);
	}
	@When("user removing Cart operations")
	public void user_removing_cart_operations() throws InterruptedException {
		cartpage =  new CartFunctiionality(driver);
		cartpage.quantity();
		Thread.sleep(2000);
		cartpage.AddToCart();
		Thread.sleep(3000);
		cartpage.ClickingCart();
		Thread.sleep(3000);
	}

	@Then("user checkout the details and payments")
	public void user_checkout_the_details_and_payments() throws InterruptedException {
		String name = ConfigReader.getProperty("name");
		String cardnumber = ConfigReader.getProperty("cardnumber");
		String cvv = ConfigReader.getProperty("cvv");
		String month = ConfigReader.getProperty("month");
		String year = ConfigReader.getProperty("year");
		
		payments = new PaymentsFunctionaly(driver);
		payments.Proceed();
		payments.checkout();
		payments.name(name);
		payments.cardnumber(cardnumber);
		payments.cvv(cvv);
		payments.month(month);
		payments.year(year);
		payments.paymentSubmit();
		
	}
	
	@After
	public void Screenshot() {
	    try {
	        // Ensure the driver is NOT null
	        if (driver != null) {
	            // Take the screenshot
	            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

	            // Create the screenshots folder if it doesn't exist
	            File screenshotsDir = new File("src/test/resources/screenshots/");
	            if (!screenshotsDir.exists()) {
	                screenshotsDir.mkdirs();
	            }

	            // Add timestamp to avoid overwrite
	            String fileName = "screenshot_" + System.currentTimeMillis() + ".jpeg";
	            File destFile = new File(screenshotsDir, fileName);

	            // Save the screenshot
	            FileHandler.copy(srcFile, destFile);
	            System.out.println("✅ Screenshot saved at: " + destFile.getAbsolutePath());
	        } else {
	            System.out.println("❌ WebDriver is null. Screenshot not taken.");
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	 //@After public void teardown() { driver.quit(); }
}
